#include "Container.h"

// Constructor for Container class
Container::Container()
{
	room = NULL;
	next = NULL;
}

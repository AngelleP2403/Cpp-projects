#ifndef _NOBLE_H_
#define _NOBLE_H_
#include "room.h"

// Create Noble class
// Part 1: Create a child class of the Room class named 'Noble'
class Noble : public Room {
public:
	Noble(string roomName, int noOfRooms, libraryType libType) : Room(roomName, noOfRooms, libType) {
	}//PART 2 HERE

	void displayRoom()  override;//PART 3 HERE

	
};




// Part2: Declare constructor which accepts the same 3 parameters as the parent class Room's constructor.
// Pass the 3 parameters to the super constructor of the Room class.


// Part 3: Re-declare the method displayRoom (virtual method found inside of parent class Room)

#endif // _NOBLE_H_


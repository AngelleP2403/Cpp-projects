
// Define displayRoom() for Noble class
// Define the function displayRoom() that you declared within the Noble class in the header file
// See expected output in question file.

// (displayList() function in the hw7.cpp should call this function.)
// Include necessary header files


#include "room.h"
#include "noble.h"

#include <iostream>

void Noble::displayRoom()
{
	cout << "Room name: " << getName() << endl;
	cout << "Number of rooms: " << getNo() << endl;
	cout << "Library: Nobel " << getLibraryType() << endl;
	// notice that no function call is needed becasue we know this is Noble class function
}
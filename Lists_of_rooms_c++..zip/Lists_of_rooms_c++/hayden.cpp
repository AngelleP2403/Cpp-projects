// Define displayRoom() for Hayden class 
// Define the function displayRoom() that you declared within the Hayden class in the header file
// See expected output in question file.

// (displayList() function in hw7.cpp should call this function.)
// Include necessary header files

#include "room.h"
#include "hayden.h"

#include <iostream>

void Hayden::displayRoom()
{
	cout << "Room name:" << getName() << endl;
	cout << "Number of rooms:" << getNo() << endl;
	cout << "Library: Hayden " << getLibraryType() << endl;
	// notice that no function call is needed becasue we know this is Hayden class function
}